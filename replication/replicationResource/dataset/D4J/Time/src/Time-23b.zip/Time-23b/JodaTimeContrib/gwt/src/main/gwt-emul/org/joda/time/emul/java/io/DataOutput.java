package java.io;

public class DataOutput {

}
