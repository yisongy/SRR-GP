package java.io;

public class CharArrayWriter extends Writer {

}
