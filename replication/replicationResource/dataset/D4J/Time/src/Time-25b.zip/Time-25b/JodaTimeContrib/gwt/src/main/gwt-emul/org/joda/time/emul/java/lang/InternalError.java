package java.lang;

public class InternalError extends Error {

}
