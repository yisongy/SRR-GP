package java.io;

public class DataInput {

}
