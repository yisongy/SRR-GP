package java.io;

public class ObjectStreamException extends IOException {

}
