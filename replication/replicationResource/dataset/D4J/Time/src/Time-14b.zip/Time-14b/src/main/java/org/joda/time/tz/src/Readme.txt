The data files in this directory were obtained from the public tz database,
http://www.twinsun.com/tz/tz-link.htm, version 2012c.
