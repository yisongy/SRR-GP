package java.lang;

public class SecurityException extends RuntimeException {

}
